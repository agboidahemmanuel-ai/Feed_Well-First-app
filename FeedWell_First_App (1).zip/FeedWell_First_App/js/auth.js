(() => {
  const $ = id => document.getElementById(id);
  let mode = "signin";
  const setMessage = (message, error = false) => {
    $("formMessage").textContent = message;
    $("formMessage").classList.toggle("error", error);
  };
  function setMode(nextMode) {
    mode = nextMode;
    const signup = mode === "signup";
    $("signinTab").classList.toggle("active", !signup);
    $("signupTab").classList.toggle("active", signup);
    $("signinTab").setAttribute("aria-selected", String(!signup));
    $("signupTab").setAttribute("aria-selected", String(signup));
    $("nameField").classList.toggle("hidden", !signup);
    $("confirmField").classList.toggle("hidden", !signup);
    $("termsLine").classList.toggle("hidden", !signup);
    $("signinOptions").classList.toggle("hidden", signup);
    $("fullName").required = signup;
    $("confirmPassword").required = signup;
    $("acceptTerms").required = signup;
    $("password").autocomplete = signup ? "new-password" : "current-password";
    $("formTitle").textContent = signup ? "Join our table." : "Welcome back.";
    $("formSubtitle").textContent = signup ? "Create an account for a smoother ordering experience." : "Sign in to make your next order a little easier.";
    $("submitButton").innerHTML = signup ? 'Create account <span>→</span>' : 'Sign in <span>→</span>';
    $("switchCopy").innerHTML = signup
      ? 'Already have an account? <button type="button" class="text-button" id="switchMode">Sign in</button>'
      : 'New to FeedWell First? <button type="button" class="text-button" id="switchMode">Create an account</button>';
    $("switchMode").addEventListener("click", () => setMode(signup ? "signin" : "signup"));
    setMessage("");
  }
  $("signinTab").addEventListener("click", () => setMode("signin"));
  $("signupTab").addEventListener("click", () => setMode("signup"));
  $("togglePassword").addEventListener("click", () => {
    const input = $("password");
    input.type = input.type === "password" ? "text" : "password";
    $("togglePassword").textContent = input.type === "password" ? "Show" : "Hide";
  });
  $("forgotPassword").addEventListener("click", () => {
    setMessage("Password reset needs a connected email service. Please contact the company for help.", true);
  });
  $("authForm").addEventListener("submit", event => {
    event.preventDefault();
    const email = $("email").value.trim().toLowerCase();
    const password = $("password").value;
    if (mode === "signup") {
      if (password !== $("confirmPassword").value) return setMessage("Your passwords do not match.", true);
      if (!$("acceptTerms").checked) return setMessage("Please agree to the terms and privacy policy.", true);
      setMessage("Demo only: account creation is not connected to a secure server yet. Do not enter a real password.", true);
    } else {
      setMessage("Demo only: sign-in is not connected to an authentication server yet. No account was accessed.", true);
    }
  });
  $("year").textContent = new Date().getFullYear();
  setMode(window.location.hash === "#signup" ? "signup" : "signin");
})();