FEEDWELL FIRST — STARTER FOOD ORDERING WEBSITE

WHAT IS INCLUDED
- Responsive landing page
- Food menu cards and category filters
- Meal search
- Shopping cart with quantity controls and localStorage persistence
- WhatsApp checkout placeholder
- SVG brand logo and app icon
- Separate CSS and JavaScript files

FOLDER STRUCTURE
FeedWell_First_App/
├── index.html
├── README.txt
├── assets/
│   └── images/
│       ├── logo.svg
│       └── app-icon.svg
├── css/
│   ├── styles.css
│   ├── components.css
│   └── responsive.css
├── js/
│   ├── main.js
│   ├── products.js
│   ├── cart.js
│   └── filters.js
└── data/
    └── products.json

HOW TO OPEN
1. Extract the ZIP file.
2. Open the extracted FeedWell_First_App folder in VS Code (File > Open Folder).
3. Install the "Live Server" extension if you do not already have it.
4. Right-click index.html and choose "Open with Live Server".
5. The page should open in your browser.

IMPORTANT CUSTOMIZATION
- Demo products and prices are in js/products.js. Replace them with the company's real menu, prices and food image URLs.
- The images are hosted on Unsplash, so an internet connection is needed for them to appear.
- Before accepting real orders, add the company's WhatsApp number in js/cart.js. Use country code with no + sign (for example, 2348012345678).
- The checkout is a starter demonstration, not a payment system. It does not collect online payments or send orders to a database.
- data/products.json is a sample data file for future development; the current menu is loaded from js/products.js.
- The website is front-end only. For real business use, add a backend, order storage, admin access, and a secure payment provider.


AUTH PAGE ADDITION
- Open auth.html to view the sign-in / create-account interface.
- The homepage has Sign in and Sign up links.
- This is a UI demo only. Authentication is NOT connected to a backend, database, or email service. Do not use real passwords.
- For production, implement secure server-side authentication, password hashing, validation, sessions, and password-reset emails.
- Your own company logo can replace assets/images/logo.svg; the favicon can be replaced at assets/images/app-icon.svg.
