(() => {
  const KEY = "feedwell_first_cart_v1";
  let cart = [];
  try { cart = JSON.parse(localStorage.getItem(KEY) || "[]"); if (!Array.isArray(cart)) cart = []; } catch { cart = []; }
  const money = value => new Intl.NumberFormat("en-NG", {style:"currency",currency:"NGN",maximumFractionDigits:0}).format(value);
  const productById = id => (window.FEEDWELL_PRODUCTS || []).find(p => p.id === Number(id));
  const save = () => { localStorage.setItem(KEY, JSON.stringify(cart)); renderCart(); };
  function addToCart(id) {
    const product = productById(id); if (!product) return;
    const existing = cart.find(item => item.id === product.id);
    if (existing) existing.qty += 1; else cart.push({id:product.id,qty:1});
    save(); window.FeedWellUI?.toast(`${product.name} added to your cart.`);
  }
  function changeQty(id, delta) {
    const item = cart.find(entry => entry.id === Number(id)); if (!item) return;
    item.qty += delta; if (item.qty <= 0) cart = cart.filter(entry => entry.id !== Number(id)); save();
  }
  function removeItem(id) { cart = cart.filter(entry => entry.id !== Number(id)); save(); }
  function renderCart() {
    const count = cart.reduce((sum,item)=>sum+item.qty,0);
    const subtotal = cart.reduce((sum,item)=>{const p=productById(item.id);return sum+(p?p.price*item.qty:0)},0);
    document.getElementById("cartCount").textContent = count;
    document.getElementById("drawerCount").textContent = `(${count})`;
    document.getElementById("cartSubtotal").textContent = money(subtotal);
    document.getElementById("cartEmpty").classList.toggle("hidden", count > 0);
    document.getElementById("cartFooter").classList.toggle("hidden", count === 0);
    const host = document.getElementById("cartItems"); host.innerHTML = "";
    cart.forEach(item => {
      const p = productById(item.id); if (!p) return;
      const row = document.createElement("div"); row.className = "cart-row";
      row.innerHTML = `<img src="${p.image}" alt=""><div><h3>${p.name}</h3><div class="cart-price">${money(p.price * item.qty)}</div><div class="quantity-controls"><button data-action="minus" data-id="${p.id}" aria-label="Decrease quantity">−</button><span>${item.qty}</span><button data-action="plus" data-id="${p.id}" aria-label="Increase quantity">+</button></div></div><button class="remove-item" data-action="remove" data-id="${p.id}">Remove</button>`;
      host.appendChild(row);
    });
  }
  document.addEventListener("click", event => {
    const btn = event.target.closest("[data-action]"); if (!btn) return;
    const id = Number(btn.dataset.id);
    if (btn.dataset.action === "plus") changeQty(id,1);
    if (btn.dataset.action === "minus") changeQty(id,-1);
    if (btn.dataset.action === "remove") removeItem(id);
  });
  document.getElementById("checkoutButton").addEventListener("click", () => {
    if (!cart.length) return;
    const lines = cart.map(item => {const p=productById(item.id);return p?`${item.qty} × ${p.name} — ${money(p.price*item.qty)}`:"";}).filter(Boolean);
    const total = cart.reduce((sum,item)=>{const p=productById(item.id);return sum+(p?p.price*item.qty:0)},0);
    const message = `Hello FeedWell First, I'd like to place an order:\n${lines.join("\n")}\nSubtotal: ${money(total)}\nPlease confirm availability and delivery details.`;
    // Replace the phone number in the WhatsApp URL in this project before taking real orders.
    const phone = ""; // Example format: 2348012345678 (country code, no + sign)
    if (!phone) { window.FeedWellUI?.toast("Demo checkout: add the company's WhatsApp number in js/cart.js to receive orders."); return; }
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`,"_blank","noopener");
  });
  window.FeedWellCart = {addToCart, renderCart, money};
  document.addEventListener("DOMContentLoaded", renderCart);
})();