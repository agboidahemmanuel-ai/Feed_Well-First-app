/* FeedWell First demo menu. Replace names, prices and image URLs with the company's real menu. */
window.FEEDWELL_PRODUCTS = [
 {id:1,name:"Jollof Rice & Chicken",category:"rice",price:4500,badge:"Customer favourite",description:"Smoky party-style jollof with seasoned chicken.",image:"https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=700&q=80"},
 {id:2,name:"Pounded Yam & Egusi",category:"swallow",price:5000,badge:"Nigerian classic",description:"Smooth pounded yam with rich egusi soup.",image:"https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=80"},
 {id:3,name:"Fried Rice & Chicken",category:"rice",price:4800,badge:"Popular",description:"Colourful fried rice served with tasty chicken.",image:"https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=700&q=80"},
 {id:4,name:"Pepper Soup",category:"protein",price:3500,badge:"Spicy & warming",description:"A warming, peppery broth with aromatic spices.",image:"https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=80"},
 {id:5,name:"Grilled Chicken",category:"protein",price:4000,badge:"Fresh off the grill",description:"Juicy seasoned chicken grilled to perfection.",image:"https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=700&q=80"},
 {id:6,name:"Moi Moi",category:"snacks",price:1200,badge:"Light & satisfying",description:"Steamed bean pudding with a soft, savoury finish.",image:"https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=80"},
 {id:7,name:"Beef Suya",category:"snacks",price:2500,badge:"Full of flavour",description:"Spiced grilled beef with a classic suya kick.",image:"https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?auto=format&fit=crop&w=700&q=80"},
 {id:8,name:"Fresh Fruit Juice",category:"drinks",price:1500,badge:"Refreshing",description:"A refreshing fruit drink to go with your meal.",image:"https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&w=700&q=80"}
];
