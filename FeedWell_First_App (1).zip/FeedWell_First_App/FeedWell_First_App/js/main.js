(() => {
  const $ = id => document.getElementById(id);
  let toastTimer;
  function toast(message) {
    const element = $("toast"); element.textContent = message; element.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => element.classList.remove("show"), 2600);
  }
  function openCart() {
    $("cartDrawer").classList.add("open"); $("drawerBackdrop").classList.add("open");
    document.body.classList.add("drawer-open"); $("cartDrawer").setAttribute("aria-hidden","false");
  }
  function closeCart() {
    $("cartDrawer").classList.remove("open"); $("drawerBackdrop").classList.remove("open");
    document.body.classList.remove("drawer-open"); $("cartDrawer").setAttribute("aria-hidden","true");
  }
  document.addEventListener("DOMContentLoaded", () => {
    $("year").textContent = new Date().getFullYear();
    $("menuToggle").addEventListener("click", () => {
      const open = $("navLinks").classList.toggle("open");
      $("menuToggle").setAttribute("aria-expanded", String(open));
      $("menuToggle").textContent = open ? "×" : "☰";
    });
    $("navLinks").querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      $("navLinks").classList.remove("open"); $("menuToggle").setAttribute("aria-expanded","false"); $("menuToggle").textContent="☰";
    }));
    $("cartOpen").addEventListener("click", openCart);
    $("cartClose").addEventListener("click", closeCart);
    $("drawerBackdrop").addEventListener("click", closeCart);
    $("browseMenu").addEventListener("click", () => { closeCart(); $("menu").scrollIntoView({behavior:"smooth"}); });
    document.addEventListener("keydown", event => { if (event.key === "Escape") closeCart(); });
    window.FeedWellFilters.render();
    window.FeedWellCart.renderCart();
  });
  window.FeedWellUI = {toast, openCart, closeCart};
})();