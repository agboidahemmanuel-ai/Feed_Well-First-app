(() => {
  let activeCategory = "all";
  let searchTerm = "";
  const host = () => document.getElementById("mealGrid");
  function render() {
    const products = window.FEEDWELL_PRODUCTS || [];
    const filtered = products.filter(p => (activeCategory === "all" || p.category === activeCategory) &&
      `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(searchTerm));
    host().innerHTML = "";
    filtered.forEach(p => {
      const card = document.createElement("article"); card.className = "meal-card";
      card.innerHTML = `<div class="meal-image-wrap"><img class="meal-image" src="${p.image}" alt="${p.name}" loading="lazy"><span class="meal-badge">${p.badge || "Made with care"}</span></div><div class="meal-info"><h3>${p.name}</h3><p>${p.description}</p><div class="meal-bottom"><span class="meal-price">${window.FeedWellCart.money(p.price)}</span><button class="add-button" data-add="${p.id}" aria-label="Add ${p.name} to cart">+</button></div></div>`;
      host().appendChild(card);
    });
    document.getElementById("emptyState").classList.toggle("hidden", filtered.length > 0);
    document.getElementById("menuStatus").textContent = `${filtered.length} ${filtered.length === 1 ? "meal" : "meals"} to explore`;
  }
  document.getElementById("categoryList").addEventListener("click", event => {
    const button = event.target.closest("[data-category]"); if (!button) return;
    activeCategory = button.dataset.category;
    document.querySelectorAll(".category-chip").forEach(chip => chip.classList.toggle("active", chip === button));
    render();
  });
  document.getElementById("searchInput").addEventListener("input", event => { searchTerm = event.target.value.trim().toLowerCase(); render(); });
  document.addEventListener("click", event => { const button = event.target.closest("[data-add]"); if (button) window.FeedWellCart.addToCart(Number(button.dataset.add)); });
  window.FeedWellFilters = {render};
})();